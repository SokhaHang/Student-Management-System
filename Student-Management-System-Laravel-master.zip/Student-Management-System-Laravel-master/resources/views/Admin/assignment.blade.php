@extends('masteradmin')

@section('title')
    Asssignment
@endsection

@section('content')
    <h1>Manage Assignment</h1>
@endsection