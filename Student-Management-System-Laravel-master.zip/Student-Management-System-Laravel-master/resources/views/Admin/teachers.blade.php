@extends('masteradmin')

@section('title')
     Teachers
@endsection

@section('content')
    <h1>Manage Teachers</h1>
@endsection