@extends('masteradmin')

@section('title')
    Exam List
@endsection

@section('content')
    <h1>Manage ExamList</h1>
@endsection