@extends('masteradmin')

@section('title')
    Class Schedule
@endsection

@section('content')
    <h1>Class Schedule</h1>
@endsection