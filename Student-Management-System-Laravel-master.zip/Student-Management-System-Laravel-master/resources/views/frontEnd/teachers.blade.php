@extends('master')

@section('title')
    Teachers
@endsection

@section('content')
    teacher page
@endsection