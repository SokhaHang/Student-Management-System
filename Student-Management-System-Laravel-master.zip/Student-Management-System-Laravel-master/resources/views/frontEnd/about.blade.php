@extends('master')

@section('title')
    About page
@endsection

@section('content')
    about page

    
@endsection