@extends('master')

@section('title')
    Noticebaord
@endsection

@section('content')
    Noticeboard
@endsection